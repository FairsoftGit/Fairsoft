create view vw_stock as
  select `liannela_fsdb`.`product`.`productName` AS `productName`, count(0) AS `stock`
  from ((`liannela_fsdb`.`item`
    left join `liannela_fsdb`.`product`
      on ((`liannela_fsdb`.`item`.`PRODUCTproductId` = `liannela_fsdb`.`product`.`productId`)))
    left join `liannela_fsdb`.`orderline`
      on ((`liannela_fsdb`.`item`.`serialNumber` = `liannela_fsdb`.`orderline`.`ITEMserialnumber`)))
  where isnull(`liannela_fsdb`.`orderline`.`ITEMserialnumber`)
  group by `liannela_fsdb`.`product`.`productName`;

