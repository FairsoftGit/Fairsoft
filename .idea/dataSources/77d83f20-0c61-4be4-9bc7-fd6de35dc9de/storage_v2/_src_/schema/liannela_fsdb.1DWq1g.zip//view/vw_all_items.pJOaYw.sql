create view vw_all_items as
  select `liannela_fsdb`.`item`.`serialNumber` AS `serialNumber`, `liannela_fsdb`.`item`.`PRODUCTproductId` AS `PRODUCTproductId`, `liannela_fsdb`.`product`.`productName` AS `productName`
  from (`liannela_fsdb`.`item`
    left join `liannela_fsdb`.`product`
      on ((`liannela_fsdb`.`item`.`PRODUCTproductId` = `liannela_fsdb`.`product`.`productId`)));

