create procedure sp_add_product(IN name        varchar(50), IN purchPrice decimal, IN salesPrice decimal,
                                IN rentalPrice decimal, IN discount decimal, IN description text)
  BEGIN
  INSERT INTO product (name, purchPrice, salesPrice, rentalPrice, discount, description)
  VALUES (`name`, `purchPrice`, `salesPrice`, `rentalPrice`, `discount`, `description`);
  SELECT * from product where id = LAST_INSERT_ID();
END;

